package com.example.hangman;

public interface WordListDownloaderInterface {
	public void downloadWords(String url);

}
