package enumerations;

public enum Sort {ALPHA, REVERSE_ALPHA};