package enumerations;

public enum InsertionMode { ADD, INSERT }
