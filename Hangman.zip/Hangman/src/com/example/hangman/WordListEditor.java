package com.example.hangman;

import java.util.ArrayList;
import java.util.Collections;

import enumerations.InsertionMode;
import enumerations.Sort;
import fileutils.FileUtils;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnKeyListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;



@SuppressLint("DefaultLocale")
public class WordListEditor extends Activity implements AdapterView.OnItemClickListener, OnKeyListener, WordListInterface{
	
	ArrayList<String> wordList;
	ListView wordListView;
	ArrayAdapter<String> wordListAdapter;
	FileUtils fileUtils;
	EditText wordListEditText;
	String fileName;
	int wordListPosition;
	Sort sortMethod = Sort.REVERSE_ALPHA;
	String sortMenuText = "Sort Z-A";
	InsertionMode insertionMode = InsertionMode.ADD;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.word_list_editor);
		init();
	}
	
	
	public void init() {
		fileUtils = new FileUtils(this);
		Intent i = getIntent();
		fileName = i.getStringExtra("fileName");
		wordList = fileUtils.getWordListAsArrayList(fileName);
		
		wordListView = (ListView)findViewById(R.id.wordListView);
		wordListAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, wordList);
		wordListView.setAdapter(wordListAdapter);
		wordListView.setOnItemClickListener(this);
		wordListAdapter.notifyDataSetChanged();
		
		setTitle("Category: " + fileName.substring(0, fileName.length()-4));
		
		registerForContextMenu(wordListView);
		
		wordListEditText = (EditText)this.findViewById(R.id.wordListEditText);
		wordListEditText.setOnKeyListener(this);
	}
	
	
	@SuppressLint("NewApi")
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.wordlist_editor_menu, menu);
		super.onCreateOptionsMenu(menu);
		return true;
	}

	
	public boolean onOptionsItemSelected(MenuItem item) {
		
		switch (item.getItemId())
	    {
		case R.id.save:
			fileUtils.writeArrayListToFile(fileName, wordList);
			toastMessage("Saved!");
			return true;
		case R.id.sort:
			toggleSort();
			item.setTitle(sortMenuText);
			return true;
		case R.id.insert_add:
			toggleInsertionMode(item);
			return true;
		default:
	        return super.onOptionsItemSelected(item);
			
	    }
	}

	
	public void onCreateContextMenu(ContextMenu menu,  View v, ContextMenu.ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		
		//Gets the position of the TextView from the overall Listview, where the context menu was created
		AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)menuInfo;
		wordListPosition = info.position;
		
	    MenuInflater inflater;
	    inflater = getMenuInflater();
	    inflater.inflate(R.menu.wordlist_editor_context_menu, menu);
	}
	
	
	@Override
	public boolean onContextItemSelected(MenuItem item) {  
	    super.onContextItemSelected(item);
	    
	    switch (item.getItemId()) {
	    case R.id.editWord:
	    	Dialog d = new WordListDialog(this, this);
	    	d.show();
	    	break;
	    case R.id.deleteWord:
	    	wordList.remove(wordListPosition);
	    	wordListAdapter.notifyDataSetChanged();
	        break;
	    default:
	        break;
	    }

	    return true;
	}
	
	
	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		
	}

	
	@Override
	public boolean onKey(View v, int keyCode, KeyEvent event) {
		
		if (event.getAction() == KeyEvent.ACTION_DOWN)
            if (keyCode == KeyEvent.KEYCODE_ENTER ) {
            	String enteredText = wordListEditText.getText().toString();
            	enteredText = enteredText.toLowerCase();
            	wordListEditText.setText("");
            	
            	
            	if(enteredText != null && enteredText != "" && isOnlyAlpha(enteredText)) {
            		switch(insertionMode){
            			case ADD:
            				wordList.add(enteredText);
            				break;
            			case INSERT:
            				wordList.add(0, enteredText);
            				break;
            		}
            		wordListAdapter.notifyDataSetChanged();
            	}
            	else
            		toastMessage("Invalid Entry");
            	
            	return true;
            	
            }
		return false;
	}
	
	
	@Override
	public void updateWord(String s) {
		wordList.set(wordListPosition, s);
		wordListAdapter.notifyDataSetChanged();	
	}
	
	public void toggleSort() {
		switch(sortMethod) {
		case ALPHA:
			Collections.sort(wordList);
			sortMethod = Sort.REVERSE_ALPHA;
			sortMenuText = "Sort Z-A";
			break;
		case REVERSE_ALPHA:
			Collections.sort(wordList);
			Collections.reverse(wordList);
			sortMethod = Sort.ALPHA;
			sortMenuText = "Sort A-Z";
			break;
		default:
			break;
		}
		wordListAdapter.notifyDataSetChanged();
	}
	
	public void sort()
	{
		switch(sortMethod) {
		case ALPHA:
			Collections.sort(wordList);
		case REVERSE_ALPHA:
			Collections.sort(wordList);
			Collections.reverse(wordList);
		default:
			Collections.sort(wordList);
			
		}
	}
	
	public boolean isOnlyAlpha(String s) {
		
		for(int i = 0; i < s.length(); i++)
		{
			if (!Character.isLetter(s.charAt(i)))
				return false;
		}
		return true;
	}
	
	public void toggleInsertionMode(MenuItem item)
	{
		switch(insertionMode){
		case ADD:
			insertionMode = InsertionMode.INSERT;
			item.setTitle("Insert");
			break;
		case INSERT:
			insertionMode = InsertionMode.ADD;
			item.setTitle("ADD");
			break;
		}
	}
	
	public void toastMessage(String s) {
		Toast toast = Toast.makeText(this, s, Toast.LENGTH_SHORT);
        toast.show();	
	}

}
