package com.example.hangman;

public interface CategoryManagerInterface {
	
	public void addCategory(String s);

}
