package com.example.hangman;

public interface WordListInterface {
	public void updateWord(String s);

}
